﻿using System.Windows.Forms;
namespace WFA_MUA
{
    partial class Menu
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtC04 = new WFA_MUA.TextboxChar();
            this.txtC12 = new WFA_MUA.TextboxChar();
            this.txtC11 = new WFA_MUA.TextboxChar();
            this.txtC20 = new WFA_MUA.TextboxChar();
            this.txtC10 = new WFA_MUA.TextboxChar();
            this.txtC19 = new WFA_MUA.TextboxChar();
            this.txtC09 = new WFA_MUA.TextboxChar();
            this.txtC22 = new WFA_MUA.TextboxChar();
            this.txtC08 = new WFA_MUA.TextboxChar();
            this.txtC26 = new WFA_MUA.TextboxChar();
            this.txtC21 = new WFA_MUA.TextboxChar();
            this.txtC96 = new WFA_MUA.TextboxChar();
            this.txtC13 = new WFA_MUA.TextboxChar();
            this.txtC03 = new WFA_MUA.TextboxChar();
            this.txtC02 = new WFA_MUA.TextboxChar();
            this.txtC01 = new WFA_MUA.TextboxChar();
            this.txtC25 = new WFA_MUA.TextboxChar();
            this.txtC24 = new WFA_MUA.TextboxChar();
            this.txtC14 = new WFA_MUA.TextboxChar();
            this.txtC05 = new WFA_MUA.TextboxChar();
            this.txtC15 = new WFA_MUA.TextboxChar();
            this.txtC18 = new WFA_MUA.TextboxChar();
            this.txtC23 = new WFA_MUA.TextboxChar();
            this.txtC17 = new WFA_MUA.TextboxChar();
            this.txtC07 = new WFA_MUA.TextboxChar();
            this.txtC06 = new WFA_MUA.TextboxChar();
            this.txtC16 = new WFA_MUA.TextboxChar();
            this.txtCurrent = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtC04
            // 
            this.txtC04.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC04.CharName = null;
            this.txtC04.Location = new System.Drawing.Point(60, 94);
            this.txtC04.Name = "txtC04";
            this.txtC04.ReadOnly = true;
            this.txtC04.Size = new System.Drawing.Size(23, 20);
            this.txtC04.TabIndex = 35;
            this.txtC04.Text = "04";
            // 
            // txtC12
            // 
            this.txtC12.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC12.CharName = null;
            this.txtC12.Location = new System.Drawing.Point(311, 172);
            this.txtC12.Name = "txtC12";
            this.txtC12.ReadOnly = true;
            this.txtC12.Size = new System.Drawing.Size(23, 20);
            this.txtC12.TabIndex = 53;
            this.txtC12.Text = "12";
            // 
            // txtC11
            // 
            this.txtC11.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC11.CharName = null;
            this.txtC11.Location = new System.Drawing.Point(301, 146);
            this.txtC11.Name = "txtC11";
            this.txtC11.ReadOnly = true;
            this.txtC11.Size = new System.Drawing.Size(23, 20);
            this.txtC11.TabIndex = 52;
            this.txtC11.Text = "11";
            // 
            // txtC20
            // 
            this.txtC20.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC20.CharName = null;
            this.txtC20.Location = new System.Drawing.Point(321, 120);
            this.txtC20.Name = "txtC20";
            this.txtC20.ReadOnly = true;
            this.txtC20.Size = new System.Drawing.Size(23, 20);
            this.txtC20.TabIndex = 51;
            this.txtC20.Text = "20";
            // 
            // txtC10
            // 
            this.txtC10.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC10.CharName = null;
            this.txtC10.Location = new System.Drawing.Point(301, 120);
            this.txtC10.Name = "txtC10";
            this.txtC10.ReadOnly = true;
            this.txtC10.Size = new System.Drawing.Size(23, 20);
            this.txtC10.TabIndex = 50;
            this.txtC10.Text = "10";
            // 
            // txtC19
            // 
            this.txtC19.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC19.CharName = null;
            this.txtC19.Location = new System.Drawing.Point(290, 94);
            this.txtC19.Name = "txtC19";
            this.txtC19.ReadOnly = true;
            this.txtC19.Size = new System.Drawing.Size(23, 20);
            this.txtC19.TabIndex = 49;
            this.txtC19.Text = "19";
            // 
            // txtC09
            // 
            this.txtC09.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC09.CharName = null;
            this.txtC09.Location = new System.Drawing.Point(261, 94);
            this.txtC09.Name = "txtC09";
            this.txtC09.ReadOnly = true;
            this.txtC09.Size = new System.Drawing.Size(23, 20);
            this.txtC09.TabIndex = 48;
            this.txtC09.Text = "09";
            // 
            // txtC22
            // 
            this.txtC22.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC22.CharName = null;
            this.txtC22.Location = new System.Drawing.Point(251, 68);
            this.txtC22.Name = "txtC22";
            this.txtC22.ReadOnly = true;
            this.txtC22.Size = new System.Drawing.Size(23, 20);
            this.txtC22.TabIndex = 47;
            this.txtC22.Text = "22";
            // 
            // txtC08
            // 
            this.txtC08.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC08.CharName = null;
            this.txtC08.Location = new System.Drawing.Point(222, 77);
            this.txtC08.Name = "txtC08";
            this.txtC08.ReadOnly = true;
            this.txtC08.Size = new System.Drawing.Size(23, 20);
            this.txtC08.TabIndex = 46;
            this.txtC08.Text = "08";
            // 
            // txtC26
            // 
            this.txtC26.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC26.CharName = null;
            this.txtC26.Location = new System.Drawing.Point(240, 30);
            this.txtC26.Name = "txtC26";
            this.txtC26.ReadOnly = true;
            this.txtC26.Size = new System.Drawing.Size(23, 20);
            this.txtC26.TabIndex = 45;
            this.txtC26.Text = "26";
            // 
            // txtC21
            // 
            this.txtC21.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC21.CharName = null;
            this.txtC21.Location = new System.Drawing.Point(60, 42);
            this.txtC21.Name = "txtC21";
            this.txtC21.ReadOnly = true;
            this.txtC21.Size = new System.Drawing.Size(23, 20);
            this.txtC21.TabIndex = 44;
            this.txtC21.Text = "21";
            // 
            // txtC96
            // 
            this.txtC96.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC96.CharName = null;
            this.txtC96.Location = new System.Drawing.Point(31, 42);
            this.txtC96.Name = "txtC96";
            this.txtC96.ReadOnly = true;
            this.txtC96.Size = new System.Drawing.Size(23, 20);
            this.txtC96.TabIndex = 43;
            this.txtC96.Text = "96";
            // 
            // txtC13
            // 
            this.txtC13.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC13.CharName = null;
            this.txtC13.Location = new System.Drawing.Point(41, 77);
            this.txtC13.Name = "txtC13";
            this.txtC13.ReadOnly = true;
            this.txtC13.Size = new System.Drawing.Size(23, 20);
            this.txtC13.TabIndex = 42;
            this.txtC13.Text = "13";
            // 
            // txtC03
            // 
            this.txtC03.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC03.CharName = null;
            this.txtC03.Location = new System.Drawing.Point(31, 103);
            this.txtC03.Name = "txtC03";
            this.txtC03.ReadOnly = true;
            this.txtC03.Size = new System.Drawing.Size(23, 20);
            this.txtC03.TabIndex = 41;
            this.txtC03.Text = "03";
            // 
            // txtC02
            // 
            this.txtC02.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC02.CharName = null;
            this.txtC02.Location = new System.Drawing.Point(13, 129);
            this.txtC02.Name = "txtC02";
            this.txtC02.ReadOnly = true;
            this.txtC02.Size = new System.Drawing.Size(23, 20);
            this.txtC02.TabIndex = 40;
            this.txtC02.Text = "02";
            // 
            // txtC01
            // 
            this.txtC01.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC01.CharName = null;
            this.txtC01.Location = new System.Drawing.Point(22, 155);
            this.txtC01.Name = "txtC01";
            this.txtC01.ReadOnly = true;
            this.txtC01.Size = new System.Drawing.Size(23, 20);
            this.txtC01.TabIndex = 39;
            this.txtC01.Text = "01";
            // 
            // txtC25
            // 
            this.txtC25.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC25.CharName = null;
            this.txtC25.Location = new System.Drawing.Point(4, 181);
            this.txtC25.Name = "txtC25";
            this.txtC25.ReadOnly = true;
            this.txtC25.Size = new System.Drawing.Size(23, 20);
            this.txtC25.TabIndex = 38;
            this.txtC25.Text = "25";
            // 
            // txtC24
            // 
            this.txtC24.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC24.CharName = null;
            this.txtC24.Location = new System.Drawing.Point(222, 56);
            this.txtC24.Name = "txtC24";
            this.txtC24.ReadOnly = true;
            this.txtC24.Size = new System.Drawing.Size(23, 20);
            this.txtC24.TabIndex = 37;
            this.txtC24.Text = "24";
            // 
            // txtC14
            // 
            this.txtC14.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC14.CharName = null;
            this.txtC14.Location = new System.Drawing.Point(98, 16);
            this.txtC14.Name = "txtC14";
            this.txtC14.ReadOnly = true;
            this.txtC14.Size = new System.Drawing.Size(23, 20);
            this.txtC14.TabIndex = 36;
            this.txtC14.Text = "14";
            // 
            // txtC05
            // 
            this.txtC05.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC05.CharName = null;
            this.txtC05.Location = new System.Drawing.Point(85, 68);
            this.txtC05.Name = "txtC05";
            this.txtC05.ReadOnly = true;
            this.txtC05.Size = new System.Drawing.Size(23, 20);
            this.txtC05.TabIndex = 34;
            this.txtC05.Text = "05";
            // 
            // txtC15
            // 
            this.txtC15.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC15.CharName = null;
            this.txtC15.Location = new System.Drawing.Point(114, 42);
            this.txtC15.Name = "txtC15";
            this.txtC15.ReadOnly = true;
            this.txtC15.Size = new System.Drawing.Size(23, 20);
            this.txtC15.TabIndex = 33;
            this.txtC15.Text = "15";
            // 
            // txtC18
            // 
            this.txtC18.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC18.CharName = null;
            this.txtC18.Location = new System.Drawing.Point(133, 4);
            this.txtC18.Name = "txtC18";
            this.txtC18.ReadOnly = true;
            this.txtC18.Size = new System.Drawing.Size(23, 20);
            this.txtC18.TabIndex = 32;
            this.txtC18.Text = "18";
            // 
            // txtC23
            // 
            this.txtC23.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC23.CharName = null;
            this.txtC23.Location = new System.Drawing.Point(188, 4);
            this.txtC23.Name = "txtC23";
            this.txtC23.ReadOnly = true;
            this.txtC23.Size = new System.Drawing.Size(23, 20);
            this.txtC23.TabIndex = 31;
            this.txtC23.Text = "23";
            // 
            // txtC17
            // 
            this.txtC17.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC17.CharName = null;
            this.txtC17.Location = new System.Drawing.Point(201, 30);
            this.txtC17.Name = "txtC17";
            this.txtC17.ReadOnly = true;
            this.txtC17.Size = new System.Drawing.Size(23, 20);
            this.txtC17.TabIndex = 30;
            this.txtC17.Text = "17";
            // 
            // txtC07
            // 
            this.txtC07.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC07.CharName = null;
            this.txtC07.Location = new System.Drawing.Point(172, 30);
            this.txtC07.Name = "txtC07";
            this.txtC07.ReadOnly = true;
            this.txtC07.Size = new System.Drawing.Size(23, 20);
            this.txtC07.TabIndex = 29;
            this.txtC07.Text = "07";
            // 
            // txtC06
            // 
            this.txtC06.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC06.CharName = null;
            this.txtC06.Location = new System.Drawing.Point(143, 30);
            this.txtC06.Name = "txtC06";
            this.txtC06.ReadOnly = true;
            this.txtC06.Size = new System.Drawing.Size(23, 20);
            this.txtC06.TabIndex = 28;
            this.txtC06.Text = "06";
            // 
            // txtC16
            // 
            this.txtC16.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtC16.CharName = null;
            this.txtC16.Location = new System.Drawing.Point(160, 56);
            this.txtC16.Name = "txtC16";
            this.txtC16.ReadOnly = true;
            this.txtC16.Size = new System.Drawing.Size(23, 20);
            this.txtC16.TabIndex = 27;
            this.txtC16.Text = "16";
            // 
            // txtCurrent
            // 
            this.txtCurrent.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txtCurrent.Location = new System.Drawing.Point(83, 155);
            this.txtCurrent.Name = "txtCurrent";
            this.txtCurrent.ReadOnly = true;
            this.txtCurrent.Size = new System.Drawing.Size(191, 20);
            this.txtCurrent.TabIndex = 54;
            this.txtCurrent.Text = "(put the mouse over some block)";
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtCurrent);
            this.Controls.Add(this.txtC04);
            this.Controls.Add(this.txtC12);
            this.Controls.Add(this.txtC11);
            this.Controls.Add(this.txtC20);
            this.Controls.Add(this.txtC10);
            this.Controls.Add(this.txtC19);
            this.Controls.Add(this.txtC09);
            this.Controls.Add(this.txtC22);
            this.Controls.Add(this.txtC08);
            this.Controls.Add(this.txtC26);
            this.Controls.Add(this.txtC21);
            this.Controls.Add(this.txtC96);
            this.Controls.Add(this.txtC13);
            this.Controls.Add(this.txtC03);
            this.Controls.Add(this.txtC02);
            this.Controls.Add(this.txtC01);
            this.Controls.Add(this.txtC25);
            this.Controls.Add(this.txtC24);
            this.Controls.Add(this.txtC14);
            this.Controls.Add(this.txtC05);
            this.Controls.Add(this.txtC15);
            this.Controls.Add(this.txtC18);
            this.Controls.Add(this.txtC23);
            this.Controls.Add(this.txtC17);
            this.Controls.Add(this.txtC07);
            this.Controls.Add(this.txtC06);
            this.Controls.Add(this.txtC16);
            this.Name = "Menu";
            this.Size = new System.Drawing.Size(353, 215);
            this.Load += new System.EventHandler(this.Menu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        #region Variables
        private TextboxChar txtC01;
        private TextboxChar txtC02;
        private TextboxChar txtC03;
        private TextboxChar txtC04;
        private TextboxChar txtC05;
        private TextboxChar txtC06;
        private TextboxChar txtC07;
        private TextboxChar txtC08;
        private TextboxChar txtC09;
        private TextboxChar txtC10;
        private TextboxChar txtC11;
        private TextboxChar txtC12;
        private TextboxChar txtC13;
        private TextboxChar txtC14;
        private TextboxChar txtC15;
        private TextboxChar txtC16;
        private TextboxChar txtC17;
        private TextboxChar txtC18;
        private TextboxChar txtC19;
        private TextboxChar txtC20;
        private TextboxChar txtC21;
        private TextboxChar txtC22;
        private TextboxChar txtC23;
        private TextboxChar txtC24;
        private TextboxChar txtC25;
        private TextboxChar txtC26;
        private TextboxChar txtC96;
        #endregion
        private TextBox txtCurrent;
    }
    
}
